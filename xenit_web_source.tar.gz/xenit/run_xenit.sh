#!/bin/sh

cmd="python3 manage.py"
service_port="9001"

opt="$1"

if [ "x${opt}" != "xrestart" -a "x${opt}" != "xstart" -a "x${opt}" != "xstop" -a "x${opt}" != "xstatus" ]
then
   echo "USE : run_xenit.sh start|stop|restart|status"
   exit 0
fi


status_tmp=`ps -elf | grep python | grep "$cmd" | grep ":${service_port}" | grep -v grep | awk {'print $4'} | wc -l`
if [ ${status_tmp} -gt 0 ]
then
    status_info="running"
else
    status_info="not running"
fi

if [ "x${opt}" = "xstart" ]
then
    if [ "${status_info}" = "running" ]
    then
        echo "SERVICE ALREADY RUNNING...."
        exit 0
    else
        django-admin compilemessages
        nohup ${cmd} runserver --verbosity=0 --noreload 0.0.0.0:${service_port} > /dev/null 2>&1 &
        #${cmd} runserver --verbosity=0 --noreload 0.0.0.0:${service_port} 
        echo "SERVICE START... [SUCCESS]"
        exit 0
    fi

elif [ "x${opt}" = "xstop" ]
then
    if [ "${status_info}" = "running" ]
    then
        for pid in `ps -elf | grep python | grep "${cmd}" | grep ":${service_port}" | grep -v grep | awk {'print $4'}`
        do
            kill -9 ${pid} > /dev/null 2>&1
        done
        echo "SERVICE STOP... [SUCCESS]"
        exit 0
    else
        echo "SERVICE ALREADY STOP... "
        exit 0
    fi

elif [ "x${opt}" = "xrestart" ]
then
    if [ "${status_info}" = "running" ]
    then
        for pid in `ps -elf | grep python | grep "${cmd}" | grep ":${service_port}" | grep -v grep | awk {'print $4'}`
        do
            kill -9 ${pid} > /dev/null 2>&1
        done
        status_tmp2=`ps -elf | grep python | grep "$cmd" | grep ":${service_port}" | grep -v grep | awk {'print $4'} | wc -l`
        if [ ${status_tmp2} -gt 0 ]
        then
            echo "SERVICE RESTART... [FAILED]"
        else
            django-admin compilemessages
            nohup ${cmd} runserver --verbosity=0 --noreload 0.0.0.0:${service_port} > /dev/null 2>&1 &
            echo "SERVICE RESTART... [SUCCESS]"
        fi
        exit 0
    else
        nohup ${cmd} runserver --verbosity=0 --noreload 0.0.0.0:${service_port} > /dev/null 2>&1 &
        echo "SERVICE RESTART... [SUCCESS]"
        exit 0
    fi

elif [ "x${opt}" = "xstatus" ]
then

    echo $status_info
    exit 0
else
   echo "USE : run_xenit.sh start|stop|status"
   exit 0
fi

exit 0

