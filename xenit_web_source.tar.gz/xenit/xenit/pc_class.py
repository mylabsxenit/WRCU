import os, re, django.db, sys, base64, subprocess, json, time, socket, hashlib, binascii
from django.utils.translation import ugettext as _
from django.utils.translation import activate

from .xenit_class import XENIT_CLASS


class PC_CLASS():

    def vncview_on(req_arr):
        resp_arr = {}
        try:
            serverip = '%s' % (str(req_arr['serverip']))
            init_conn = PC_CLASS.init_connect()

            dbconn = django.db.connections['default'].cursor()
            DBSQL0 = "select * from pc where pc_ipaddr = '%s'" % (str(serverip))
            dbconn.execute(DBSQL0)
            DBROWS0 = dbconn.fetchall()
            if int(len(DBROWS0)) < 1:
                dbconn.close()
                resp_arr['response'] = 'failed'
                resp_arr['error_message'] = 'failed'
                return resp_arr
            server_idx = '%s' % (str(DBROWS0[0][0]))

            DBSQL1 = "select * from pc where xenit_nick <> '' and pc_ipaddr <> '%s'" % (str(serverip))
            dbconn.execute(DBSQL1)
            DBROWS1 = dbconn.fetchall()
            iplist = ''
            for DBDATA1 in DBROWS1:
                idx = '%s' % (str(DBDATA1[0]))
                iplist += '%s_' % (str(idx))
            dbconn.close()

            vnc_req = {}
            vnc_req['execmod'] = 'vncview'
            vnc_req['mod'] = 'individual'
            vnc_req['pcidx'] = server_idx
            vnc_req['msg'] = ''
            vnc_view = PC_CLASS.pccommandexec(vnc_req)

            vncconn_req = {}
            vncconn_req['execmod'] = 'connect'
            vncconn_req['mod'] = 'lists'
            vncconn_req['msg'] = serverip
            vncconn_req['pcidx'] = iplist
            vncconn = PC_CLASS.pccommandexec(vncconn_req)

            resp_arr['response'] = 'success'
            resp_arr['error_message'] = 'success'
            resp_arr['error_message2'] = vnc_view
            resp_arr['error_message3'] = vncconn
        except Exception as e:
            resp_arr['response'] = 'failed'
            resp_arr['error_message'] = 'failed %s ' % (str(e.args[0]))
        return resp_arr


    def init_connect():
        resp_arr = {}
        try:
            vnc_req = {}
            vnc_req['execmod'] = 'disconnect'
            vnc_req['mod'] = 'all'
            vnc_req['pcidx'] = 'all'
            vnc_disconnect = PC_CLASS.pccommandexec(vnc_req)

            vncoff_req = {}
            vncoff_req['execmod'] = 'vncoff'
            vncoff_req['mod'] = 'all'
            vncoff_req['pcidx'] = 'all'
            vnc_vncoff = PC_CLASS.pccommandexec(vncoff_req)

            resp_arr['response'] = 'success'
            resp_arr['error_message'] = 'success'
        except Exception as e:
            resp_arr['response'] = 'failed'
            resp_arr['error_message'] = 'failed'
        return resp_arr


    def monitor_nodes_all():
        resp_arr = {}
        try:
            dbconn = django.db.connections['default'].cursor()
            DBSQL1 = "select * from pc order by pc_name"
            dbconn.execute(DBSQL1)
            DBROWS1 = dbconn.fetchall()
            data_arr = []
            for DBDATA1 in DBROWS1:
                data_obj = {}
                data_obj['idx'] = '%s' % (str(DBDATA1[0]))
                data_obj['pc_ipaddr'] = '%s' % (str(DBDATA1[1]))
                data_obj['pc_hwaddr'] = '%s' % (str(DBDATA1[2]))
                data_obj['pc_name'] = '%s' % (str(DBDATA1[3]))
                data_obj['pc_info'] = '%s' % (str(DBDATA1[5]))
                data_obj['pc_alias'] = '%s' % (str(DBDATA1[6].replace('@','')))
                data_obj['xenit_nick'] = '%s' % (str(DBDATA1[7]))
                data_obj['xenit_nick_old'] = '%s' % (str(DBDATA1[8]))
                data_obj['xenit_main'] = '%s' % (str(DBDATA1[9]))
                data_obj['xenit_update'] = '%s' % (str(DBDATA1[10]))
                data_obj['xenit_mod'] = '%s' % (str(DBDATA1[11]))
                data_obj['reg_date'] = '%s' % (str(DBDATA1[12]))
                data_obj['xenit_trans'] = '%s' % (str(DBDATA1[13]))
                
                data_obj['pc_inter'] = '%s' % (str(DBDATA1[14]))
                data_obj['pc_locks'] = '%s' % (str(DBDATA1[15]))
                data_arr.append(data_obj)
            dbconn.close()

            resp_arr['response'] = 'success'
            resp_arr['error_message'] = 'success'
            resp_arr['data'] = data_arr
        except Exception as e:
            resp_arr['response'] = 'failed'
            resp_arr['error_message'] = 'failed'
            resp_arr['data'] = []
        return resp_arr

    def getinfo_node(req_arr):
        resp_arr = {}
        try:
            mac = '%s' % (str(req_arr["mac"].lower()))
            dbconn = django.db.connections['default'].cursor()
            DBSQL1 = "select * from pc where pc_hwaddr = '%s'" % (str(mac))
            dbconn.execute(DBSQL1)
            DBROWS1 = dbconn.fetchall()
            if int(len(DBROWS1)) < 1:
                dbconn.close()
                resp_arr['response'] = 'failed'
                resp_arr['error_message'] = 'pc does not exist.'
                return resp_arr
            dbconn.close()
            resp_arr['response'] = 'success'
            resp_arr['error_message'] = 'success'
            resp_arr['mod'] = ''
        except Exception as e:
            resp_arr['response'] = 'failed'
            resp_arr['error_message'] = 'except error'
        return resp_arr


    def search_nodes(req_arr):
        resp_arr = {}
        try:
            searchword = req_arr['searchword']
            page = req_arr['page']
            next_page = int(page) + 1
            lists = 50
            start = (page -1) * lists
            dbconn = django.db.connections['default'].cursor()
            if str(searchword) == '':
                where = ""
            else:
                where = " where (pc_ipaddr like '%%%s%%' or pc_hwaddr like '%%%s%%' or xenit_nick like '%%%s%%')" % (str(searchword), str(searchword), str(searchword))
            DBSQL1 = "select * from pc %s order by pc_name asc limit %s, %s" % (str(where), str(start), str(lists))
            dbconn.execute(DBSQL1)
            DBROWS1 = dbconn.fetchall()
            data_arr = []
            for DBDATA1 in DBROWS1:
                pc_rom = '%s' % (str(DBDATA1[4]))
                if pc_rom != '':
                    DBSQL2 = "select * from sys_bootrom where idx = '%s'" % (str(pc_rom))
                    dbconn.execute(DBSQL2)
                    DBROWS2 = dbconn.fetchall()
                    if int(len(DBROWS2)) > 0:
                        pc_rom_name = '%s' % (str(DBROWS2[0][2]))
                    else:
                        pc_rom_name = ''
                else:
                    pc_rom_name = ''
                data_obj = {}
                data_obj['idx'] = '%s' % (str(DBDATA1[0]))
                data_obj['pc_ipaddr'] = '%s' % (str(DBDATA1[1]))
                data_obj['pc_hwaddr'] = '%s' % (str(DBDATA1[2]))
                data_obj['pc_name'] = '%s' % (str(DBDATA1[3]))
                data_obj['pc_rom'] = '%s' % (str(DBDATA1[4]))
                data_obj['pc_rom_name'] = '%s' % (str(pc_rom_name))
                data_obj['pc_info'] = '%s' % (str(DBDATA1[5]))
                data_obj['pc_alias'] = '%s' % (str(DBDATA1[6].replace('@','')))
                data_obj['xenit_nick'] = '%s' % (str(DBDATA1[7]))
                data_obj['xenit_nick_old'] = '%s' % (str(DBDATA1[8]))
                data_obj['xenit_main'] = '%s' % (str(DBDATA1[9]))
                data_obj['xenit_update'] = '%s' % (str(DBDATA1[10]))
                data_obj['xenit_mod'] = '%s' % (str(DBDATA1[11]))
                data_obj['reg_date'] = '%s' % (str(DBDATA1[12]))
                data_obj['xenit_trans'] = '%s' % (str(DBDATA1[13]))
                
                data_obj['pc_inter'] = '%s' % (str(DBDATA1[14]))
                data_obj['pc_locks'] = '%s' % (str(DBDATA1[15]))
                data_arr.append(data_obj)
            if int(len(DBROWS1)) < lists:
                next_page = 'N'
            dbconn.close()
            resp_arr['response'] = 'success'
            resp_arr['error_message'] = 'success'
            resp_arr['data'] = data_arr
            resp_arr['next_page'] = next_page
        except Exception as e:
            resp_arr['response'] = 'failed'
            resp_arr['error_message'] = 'failed'
            resp_arr['data'] = []
            resp_arr['next_page'] = 'N'
        return resp_arr


    def pccommandexec_mod2(reqarr):
        allpc_status = []
        resp_arr = {}
        tmpdir = './xenit/static/tmpdata'
        try:
            if os.path.exists(tmpdir) == False:
                os.mkdir(tmpdir)
        except Exception as e:
            os.mkdir(tmpdir)

        try:
            if int(len(reqarr)) < 1:
                resp_arr['response'] = 'fail'
                resp_arr['error_message'] = _('A temporary failure occurred. Please try again')
                resp_arr['allpcresult'] = allpc_status
                return resp_arr

            cmdmod = '%s' % (str(reqarr['cmdmod']))
            tmp_conts = ''
            for datai in reqarr['datas']:
                pc_idx = '%s' % (str(datai['pc_idx']))
                pc_ip = '%s' % (str(datai['pc_ip']))
                pc_alias = '%s' % (str(datai['pc_alias']))
                msg = '%s' % (str(datai['msg']))
                tmp_conts += '%s|%s|%s|%s\n' % (pc_idx, pc_ip, pc_alias, msg)
            
            if cmdmod == 'shot':
                if os.path.isdir("/home/xenit/shots"):
                    #오래된파일지우기 12초
                    os.system('find /home/xenit/shots/* -mmin +0.2 -exec rm {} \;')
                else:
                    #폴더만들고 링크걸기
                    os.system('mkdir /home/xenit/shots')
                    os.system('ln -s /home/xenit/shots /home/xenit/xenit/xenit/static/shots') 
                    #오래된파일지우기 12초
                    os.system('find /home/xenit/shots/* -mmin +0.2 -exec rm {} \;')   
            
            if tmp_conts != '':
                utime = time.time()
                utime = int(utime)
                tmpfile = '%s/sfile_%s' % (str(tmpdir), str(utime))
                if os.path.exists(tmpfile):
                    for i in range(5):
                        tmpfile = '%s_%s' % (tmpfile, str(i))
                        if os.path.exists(tmpfile) == False:
                            break
                
                if os.path.exists(tmpfile):
                    dbconn.close()
                    resp_arr['response'] = 'fail'
                    resp_arr['error_message'] = 'fail21'
                    resp_arr['allpcresult'] = allpc_status
                    return resp_arr

                wfile = open(tmpfile, "w")
                wfile.write("%s" %(str(tmp_conts)))
                wfile.close()
                req_arr = {}
                req_arr['tmpfile'] = tmpfile
                allpc_status = XENIT_CLASS.exec_window_client(req_arr)

            resp_arr['response'] = 'success'
            resp_arr['error_message'] = 'success'
            resp_arr['allpcresult'] = allpc_status
            return resp_arr
        except Exception as e:
            resp_arr['response'] = 'fail'
            resp_arr['error_message'] = 'fail22 %s' % (str(e.args[0]))
            return resp_arr
    
    
    def pccommandexec(req):
            
        execmod = req['execmod']
        mod = req['mod']
        pc_idx = req['pcidx']
        resp_arr = {}
        tmpdir = './xenit/static/tmpdata'
        try:
            if os.path.exists(tmpdir) == False:
                os.mkdir(tmpdir)
        except Exception as e:
            os.mkdir(tmpdir)

        try:
            dbconn = django.db.connections['default'].cursor()

####            
            if execmod == 'vncoff':
                req_command = 'vncoff@@vncoff'
            elif execmod == 'vnccon':
                req_command = 'vnccon@@vnccon'
            elif execmod == 'vncview':
                req_command = 'vncview@@vncview'
            elif execmod == 'disconnect':
                req_command = 'disconnect@@disconncet'            
            elif execmod == 'connect':
                ipaddr = '%s' % (str(req['msg']))
                req_command = 'connect@@%s' % (str(ipaddr))

            else:
                req_command = '%s@@%s' % (str(execmod), str(execmod))

            if mod == 'all':
                DBSQL1 = "select * from pc where xenit_nick <> '' order by pc_alias asc"
            elif mod == 'lists':
                DBSQL1 = "select * from pc order by pc_alias asc"
            else:
                DBSQL1 = "select * from pc where idx ='%s'" % (str(pc_idx))
            dbconn.execute(DBSQL1)
            DBROWS1 = dbconn.fetchall()
            if int(len(DBROWS1)) < 1:
                dbconn.close()
                resp_arr['response'] = 'fail'
                resp_arr['error_message'] = 'There is no Node in the Node group are matched.'
                resp_arr['allpcresult'] = []
                return resp_arr

            tmp_conts = ''

            if mod == 'lists':
                for tmpidx in pc_idx.split('_'):
                    if str(tmpidx) != '':
                        DBSQL2 = "select * from pc where idx ='%s'" % (str(tmpidx))
                        dbconn.execute(DBSQL2)
                        DBROWS2 = dbconn.fetchall()
                        if int(len(DBROWS2)) >= 1:
                            pc_idx = DBROWS2[0][0]
                            pc_ip = DBROWS2[0][1]
                            pc_alias = DBROWS2[0][6].replace('@','')
                            msg = '%s' % (str(req_command))
                            tmp_conts += '%s|%s|%s|%s\n' % (str(pc_idx), str(pc_ip), str(pc_alias), msg)
            else:
                for DBDATA in DBROWS1:
                    pc_idx = DBDATA[0]
                    pc_ip = DBDATA[1]
                    pc_alias = DBDATA[6].replace('@','')
                    msg = '%s' % (str(req_command))
                    tmp_conts += '%s|%s|%s|%s\n' % (str(pc_idx), str(pc_ip), str(pc_alias), msg)

            dbconn.close()

            if tmp_conts != '':
                utime = time.time()
                utime = int(utime)
                tmpfile = '%s/sfile_%s' % (str(tmpdir), str(utime))
                if os.path.exists(tmpfile):
                    for i in range(5):
                        tmpfile = '%s_%s' % (tmpfile, str(i))
                        if os.path.exists(tmpfile) == False:
                            break
                
                if os.path.exists(tmpfile):
                    dbconn.close()
                    resp_arr['response'] = 'fail'
                    resp_arr['error_message'] = 'A temporary failure occurred. Please try again'
                    resp_arr['allpcresult'] = []
                    return resp_arr

                wfile = open(tmpfile, "w")
                wfile.write("%s" %(str(tmp_conts)))
                wfile.close()
                req_arr = {}
                req_arr['tmpfile'] = tmpfile
                allpc_status = XENIT_CLASS.exec_window_client(req_arr)
            else:
                allpc_status = []

            resp_arr['response'] = 'success'
            resp_arr['error_message'] = 'success'
            resp_arr['allpcresult'] = allpc_status
            return resp_arr
        except Exception as e:
            resp_arr['response'] = 'fail'
            resp_arr['error_message'] = 'A temporary failure occurred. Please try again'
            return resp_arr



    def pcinfoformodi(pcidx):
        resp_arr = {}
        try:


            dbconn = django.db.connections['default'].cursor()
            DBSQL1 = "select * from pc where idx = '%s'" % (str(pcidx))
            dbconn.execute(DBSQL1)
            DBROWS1 = dbconn.fetchall()
            for DBDATA in DBROWS1:
                data_arr = {}
                data_arr['idx'] = DBDATA[0]
                data_arr['pc_ipaddr'] = DBDATA[1]
                data_arr['pc_hwaddr'] = DBDATA[2]
                data_arr['pc_name'] = DBDATA[3]
                data_arr['pc_rom'] = DBDATA[4]
                data_arr['pc_info'] = DBDATA[5]
                data_arr['pc_alias'] = DBDATA[6].replace('@','')
                data_arr['xenit_nick'] = DBDATA[7]
                data_arr['xenit_main'] = DBDATA[9]
                data_arr['xenit_update'] = DBDATA[10]
                data_arr['xenit_mod'] = DBDATA[11]
                data_arr['xenit_trans'] = DBDATA[13]
            resp_arr['pc_data'] = data_arr
            resp_arr['response'] = 'success'
            resp_arr['error_message'] = 'success'
            dbconn.close()
        except Exception as e:
            resp_arr['response'] = 'fail'
            resp_arr['error_message'] = 'fail'
        return resp_arr


    def pcdelete(req_arr):
        resp_arr = {}
        pc_idx = req_arr['pc_idx']

        try:
            dbconn = django.db.connections['default'].cursor()
            DBSQL1 = "delete from pc where idx = '%s'" % (str(pc_idx))
            dbconn.execute(DBSQL1)
            dbconn.close()
           
            resp_arr['response'] = 'success'
            resp_arr['error_message'] = 'success'

        except Exception as e:
            resp_arr['response'] = 'fail'
            resp_arr['error_message'] = 'A temporary failure occurred. Please try again.5'
        return resp_arr

    def pcmodi(req_arr):
        resp_arr = {}
        pc_idx = req_arr['pc_idx']
        pc_type = req_arr['pc_type']
        pc_rom = req_arr['pc_rom']
        pc_nickname = req_arr['pc_nickname']
        pc_ip = req_arr['pc_ip']
        pc_mac = req_arr['pc_mac'].lower()
        pc_info = req_arr['pc_info']
        pc_main = req_arr['pc_main'].lower()
        pc_trans = req_arr['pc_trans'].lower()
        pc_name = 'pc%s%s' % (str(pc_ip.split('.')[2]), str(pc_ip.split('.')[3]))
        pc_update = 'n'
        dhcp_update = 'n'
        samba_update = 'n'
        try:
            pc_alias = (( int(len(pc_nickname))) * '@') + pc_nickname
            dbconn = django.db.connections['default'].cursor()
            #duplicate check
            PREDBSQL1 = "select * from pc where pc_ipaddr = '%s' and idx <> '%s'" % (str(pc_ip), str(pc_idx))
            dbconn.execute(PREDBSQL1)
            PREDBROWS1 = dbconn.fetchall()
            if int(len(PREDBROWS1)) > 0:
                dbconn.close()
                resp_arr['response'] = 'fail'
                resp_arr['error_message'] = 'Duplicate IP exists.'
                return resp_arr
            PREDBSQL2 = "select * from pc where pc_hwaddr = '%s' and idx <> '%s'" % (str(pc_mac), str(pc_idx))
            dbconn.execute(PREDBSQL2)
            PREDBROWS2 = dbconn.fetchall()
            if int(len(PREDBROWS2)) > 0:
                dbconn.close()
                resp_arr['response'] = 'fail'
                resp_arr['error_message'] = 'Duplicate MAC exists.'
                return resp_arr
            PREDBSQL3 = "select * from pc where pc_alias = '%s' and idx <> '%s'" % (str(pc_alias), str(pc_idx))
            dbconn.execute(PREDBSQL3)
            PREDBROWS3 = dbconn.fetchall()
            if int(len(PREDBROWS3)) > 0:
                dbconn.close()
                resp_arr['response'] = 'fail'
                resp_arr['error_message'] = 'Duplicate Node NAME exists.'
                return resp_arr
            DBSQL1 = "select * from pc where idx = '%s'" % (str(pc_idx))
            dbconn.execute(DBSQL1)
            DBROWS1 = dbconn.fetchall()
            for OBJ1 in DBROWS1:
                orig_pc_idx = '%s' % (str(OBJ1[0]))
                orig_pc_ip = '%s' % (str(OBJ1[1]))
                orig_pc_mac = '%s' % (str(OBJ1[2]))
                orig_pc_name = '%s' % (str(OBJ1[3]))
                orig_pc_rom = '%s' % (str(OBJ1[4]))
                orig_xenit_nick = '%s' % (str(OBJ1[7]))
                orig_xenit_nick_old = '%s' % (str(OBJ1[8]))
                orig_xenit_main = '%s' % (str(OBJ1[9]))
                orig_xenit_trans = '%s' % (str(OBJ1[13]))

            #db update
            DBSQL3 = "update pc set pc_ipaddr = '%s', pc_hwaddr = '%s', pc_name = '%s', pc_rom = '%s', pc_info = '%s', pc_alias = '%s', xenit_nick = '%s', xenit_main = '%s', xenit_update = '%s', xenit_trans='%s' where idx = '%s'" % (str(pc_ip), str(pc_mac), str(pc_name), str(pc_rom), str(pc_info), str(pc_alias), str(pc_type), str(pc_main), str(pc_update), str(pc_trans), str(orig_pc_idx))
            dbconn.execute(DBSQL3)
            # pc main update
            if pc_main == 'y':
                DBSQL4 = "update pc set xenit_main = 'n', xenit_trans = 'n' where (xenit_nick = '%s' and idx <> '%s')" % ( str(pc_type), str(pc_idx))
                dbconn.execute(DBSQL4)
            dbconn.close()
            
            resp_arr['response'] = 'success'
            resp_arr['error_message'] = 'success'
        except Exception as e:
            resp_arr['response'] = 'fail'
            resp_arr['error_message'] = 'A temporary failure occurred. Please try again.'
        return resp_arr

    def pcregistrationlinux(req_arr):
        resp_arr = {}


    def pcregistration(req_arr):
        resp_arr = {}
        pc_type = req_arr['pc_type']
        pc_rom = req_arr['pc_rom']
        pc_nickname = req_arr['pc_nickname']
        pc_ip = req_arr['pc_ip']
        pc_mac = req_arr['pc_mac'].lower()
        pc_info = req_arr['pc_info']
        pc_main = req_arr['pc_main'].lower()
        pc_mod = req_arr['pc_mod'].lower()
        pc_name = 'pc%s%s' % (str(pc_ip.split('.')[2]), str(pc_ip.split('.')[3]))


        try:
            pc_alias = (( int(len(pc_nickname))) * '@') + pc_nickname
            dbconn = django.db.connections['default'].cursor()

            #duplicate check
            DBSQL1 = "select * from pc where pc_ipaddr = '%s' or pc_hwaddr = '%s' or pc_alias = '%s'" % (str(pc_ip), str(pc_mac), str(pc_alias))
            dbconn.execute(DBSQL1)
            DBROWS1 = dbconn.fetchall()
            if int(len(DBROWS1)) > 0:
                #dbconn.close()
                resp_arr['response'] = 'fail'
                resp_arr['error_message'] = 'Duplicate IP or MAC or Node NAME exists.'
                return resp_arr
            #duplicate check
            if pc_type != '':
                if pc_main == 'y':
                    DBSQL2 = "update pc set xenit_main = 'n' where xenit_nick = '%s' and xenit_main = 'y'" % (str(pc_type))
                    dbconn.execute(DBSQL2)
            else:
                pc_main = 'n'
  
            #db insert
            DBSQL3 = "insert into pc (pc_ipaddr, pc_hwaddr, pc_name, pc_rom, pc_info, pc_alias, xenit_nick, xenit_nick_old, xenit_main, xenit_update, xenit_mod, reg_date) values('%s','%s','%s','%s','%s','%s','%s','','%s','%s','%s',NOW())" % (str(pc_ip), str(pc_mac), str(pc_name), str(pc_rom), str(pc_info), str(pc_alias), str(pc_type), str(pc_main), 'y', str(pc_mod))
            dbconn.execute(DBSQL3)
            #db insert
        except Exception as e:
            resp_arr['response'] = 'fail'
            resp_arr['error_message'] = 'A temporary failure occurred. Please try again.'+e.args[0]
            return resp_arr


        dbconn.close()
        resp_arr['response'] = 'success'
        resp_arr['error_message'] = 'success'
        return resp_arr

