from django.shortcuts import render, render_to_response
from django.views.generic import TemplateView
from django.http import HttpResponse
from django.contrib.sessions.backends.db import SessionStore
import json, datetime, os
from django.views.decorators.csrf import csrf_exempt
from django.http.response import HttpResponseRedirect


from django.utils.translation import ugettext as _
from django.utils.translation import activate

from .xenit_class import XENIT_CLASS
from .pc_class import PC_CLASS
from .decorators import login_required
from .member import MEMBER



class XENIT_LOGIN():
    def login(request):   
        
        result = []
        if(request.session.get('result',False)):        
            return render(request, 'login.html', {"userinfo":result})
        else:
            return render(request, 'login.html')

    def login_post(request):  
        try:
            userid =   request.POST['id']
            password = request.POST['pw']
            response = MEMBER.login(userid, password)   
            if response['response'] == 'success':
                request.session['response']= 'success'        
                request.session['name']=response['member_info']['userid']
                request.session['nick']=response['member_info']['nick']
                request.session['level']=response['member_info']['level']
                response_data = {}
                response_data['response'] = 'success'
                response_data['response_msg'] = 'Login success'
            else:
                if request.session.get('name', False):
                    del request.session['name']
                    del request.session['nick']
                    del request.session['level']
                if request.session.get('response',False):
                    del response.session['response']
                response_data = {}
                response_data['response'] = 'failed'
                response_data['response_msg'] = 'Login failed %s' % (str(response['err_msg']))
            return HttpResponse( json.dumps(response_data), content_type="application/json")
        except Exception as e:
            response_data = {}
            response_data['response'] = 'failed'
            response_data['response_msg'] = 'err111 : %s' % (str(e.args[0]))
            return HttpResponse( json.dumps(response_data), content_type="application/json")
    
    def openlogin(request):
        return render(request, 'login.html')
    
    def logout(request):

        del request.session['name']
        del request.session['nick']
        del request.session['level']
        return HttpResponseRedirect('login')


class XENITPC():
        

    @login_required
    def node_info(request):

        return render(request,"node_info.html")

    @login_required
    def monitor(request):
        return render(request,"node_monitor.html")        

    def monitor_prepare(request):
        return render(request,"node_monitor_prepare.html")        

    @csrf_exempt
    def registrationfile(request):

        try:
            resp_arr = PC_CLASS.handle_uploaded_file(request.FILES['pc_file'])
        except Exception as e:
            resp_arr['response'] = _('fail')
            resp_arr['error_message'] = _('upload fail')
        result = HttpResponse( json.dumps(resp_arr), content_type="application/json")
        return result

    @csrf_exempt
    def registrationlinux(request):
        try:
            req_arr = {}
            req_arr['pc_type'] = ''
            req_arr['pc_rom'] = ''
            req_arr['pc_nickname'] = request.POST['nickname']
            req_arr['pc_ip'] = request.POST['pc_ip']
            req_arr['pc_mac'] = request.POST['pc_mac']
            req_arr['pc_info'] = ''
            req_arr['pc_main'] = 'n'
            req_arr['pc_mod'] = 'n'
            req_arr['pc_trans'] = 'n'
            req_result = PC_CLASS.pcregistrationlinux(req_arr)
            response = req_result['response']
        except Exception as e:
            response = 'fail'
        result = HttpResponse( response )
        return result

    def requestAPI(request):
        
        resp_arr = {}
        if not 'reqmod' in request.POST:
            resp_arr['response'] = 'fail'
            resp_arr['error_message'] = 'reqmod error'
            result = HttpResponse( json.dumps(resp_arr), content_type="application/json")
            return result
        reqmod = request.POST['reqmod']
####        
        if reqmod == 'vncoff':
            req_arr = {}
            req_arr['execmod'] = 'vncoff'
            req_arr['mod'] = request.POST['mod']
            req_arr['pcidx'] = request.POST['pcidx']
            req_result = PC_CLASS.pccommandexec(req_arr)
            resp_arr['arr'] = req_result
        elif reqmod == 'vnccon':
            req_arr = {}
            req_arr['execmod'] = 'vnccon'
            req_arr['mod'] = request.POST['mod']
            req_arr['pcidx'] = request.POST['pcidx']
            req_result = PC_CLASS.pccommandexec(req_arr)
            resp_arr['arr'] = req_result
        elif reqmod == 'vncview':
            req_arr = {}
            req_arr['execmod'] = 'vncview'
            req_arr['mod'] = request.POST['mod']
            req_arr['pcidx'] = request.POST['pcidx']
            req_result = PC_CLASS.pccommandexec(req_arr)
            resp_arr['arr'] = req_result
        elif reqmod == 'disconnect':
            req_arr = {}
            req_arr['execmod'] = 'disconnect'
            req_arr['mod'] = request.POST['mod']
            req_arr['pcidx'] = request.POST['pcidx']
            req_result = PC_CLASS.pccommandexec(req_arr)
            resp_arr['arr'] = req_result
        elif reqmod == 'conncect':
            try:
                req_arr = {}
                req_arr['execmod'] = 'conncect'
                req_arr['mod'] = request.POST['mod']
                req_arr['pcidx'] = request.POST['pcidx']
                req_arr['msg'] = request.POST['msg']
                req_result = PC_CLASS.pccommandexec(req_arr)
                resp_arr['arr'] = req_result
            except Exception as e:
                resp_arr2 = {}
                resp_arr2['response'] = 'failed'
                resp_arr2['error_message'] = 'failed'
                resp_arr['arr'] = resp_arr2                    
        elif reqmod == 'monitor_nodes_all':
            try:
                req_result = PC_CLASS.monitor_nodes_all()
                resp_arr['arr'] = req_result
            except Exception as e:
                resp_arr2 = {}
                resp_arr2['response'] = 'failed'
                resp_arr2['error_message'] = 'failed'
                resp_arr2['data'] = []
                resp_arr2['next_page'] = 'N'
                resp_arr['arr'] = resp_arr2
        elif reqmod == 'init_connect':
            try:
                req_result = PC_CLASS.init_connect()
                resp_arr['arr'] = req_result
            except Exception as e:
                resp_arr2 = {}
                resp_arr2['response'] = 'failed'
                resp_arr2['error_message'] = 'failed'
                resp_arr['arr'] = resp_arr2
        elif reqmod == 'vncview_on':
            try:
                req_arr = {}
                req_arr['serverip'] = request.POST['serverip']
                req_result = PC_CLASS.vncview_on(req_arr)
                resp_arr['arr'] = req_result
            except Exception as e:
                resp_arr2 = {}
                resp_arr2['response'] = 'failed'
                resp_arr2['error_message'] = 'failed'
                resp_arr['arr'] = resp_arr2
####

        elif reqmod == 'reset':
            req_arr = {}
            req_arr['mod'] = request.POST['mod']
            req_arr['pcidx'] = request.POST['pcidx']
            req_result = PC_CLASS.xenitpcreset(req_arr)
            resp_arr['arr'] = req_result
        elif reqmod == 'updatelanguage':
            req_arr = {}
            req_arr['item_name'] = 'lang'
            req_arr['item_value'] = request.POST['lang_sel']
            req_result = PC_CLASS.update_conf_ext(req_arr)
            if "lang" in request.session:
                del request.session['lang'] 
                del request.session['result'] 
            request.session['result']= 'success'
            request.session['lang']= req_arr['item_value']
            resp_arr['response'] = req_result['response']
            resp_arr['error_message'] = req_result['error_message']
        elif reqmod == 'updatepclist':
            req_arr = {}
            req_arr['item_name'] = 'pclist'
            req_arr['item_value'] = request.POST['cnt_info'].split('coms_name')[1]
            req_result = PC_CLASS.update_conf_ext(req_arr)  #######
            resp_arr['response'] = req_result['response']
            resp_arr['error_message'] = req_result['error_message']
        elif reqmod == 'pcregistration':
            req_arr = {}
            req_arr['pc_type'] = request.POST['pc_type']
            req_arr['pc_rom'] = request.POST['pc_rom']
            req_arr['pc_nickname'] = request.POST['pc_nickname']
            req_arr['pc_ip'] = request.POST['pc_ip']
            req_arr['pc_mac'] = request.POST['pc_mac']
            req_arr['pc_info'] = request.POST['pc_info']
            req_arr['pc_main'] = request.POST['pc_main']
            req_arr['pc_mod'] = request.POST['pc_mod']
            req_arr['pc_trans'] = request.POST['pc_trans']
            req_result = PC_CLASS.pcregistration(req_arr) #######
            resp_arr['response'] = req_result['response']
            resp_arr['error_message'] = req_result['error_message']
        elif reqmod == 'pcmodification':
            req_arr = {}
            req_arr['pc_idx'] = request.POST['pc_idx']
            req_arr['pc_type'] = request.POST['pc_type']
            req_arr['pc_rom'] = request.POST['pc_rom']
            req_arr['pc_nickname'] = request.POST['pc_nickname']
            req_arr['pc_ip'] = request.POST['pc_ip']
            req_arr['pc_mac'] = request.POST['pc_mac']
            req_arr['pc_info'] = request.POST['pc_info']
            req_arr['pc_main'] = request.POST['pc_main']
            req_arr['pc_trans'] = request.POST['pc_trans']
            req_result = PC_CLASS.pcmodi(req_arr) #######
            resp_arr['response'] = req_result['response']
            resp_arr['error_message'] = req_result['error_message']
        elif reqmod == 'pcdelete':
            req_arr = {}
            req_arr['pc_idx'] = request.POST['pc_idx']
            req_result = PC_CLASS.pcdelete(req_arr) ########
            resp_arr['response'] = req_result['response']
            resp_arr['error_message'] = req_result['error_message']
        elif reqmod == 'pcinfoformodi':
            pcidx = request.POST['pcidx']
            req_result = PC_CLASS.pcinfoformodi(pcidx) ########
            resp_arr['arr'] = req_result
        elif reqmod == 'pc_type_lists':
            req_result = PC_CLASS.get_pc_type_all()
            resp_arr['arr'] = req_result
        
        elif reqmod == 'get_all_pclist':
            req_result = PC_CLASS.get_all_pclist()
            resp_arr['arr'] = req_result
        
        elif reqmod == 'get_all_pclist_onair':
            req_result = PC_CLASS.get_all_pclist_onair()
            resp_arr['arr'] = req_result
            
        elif reqmod == 'allocatepcgroup':
            req_arr = {}
            req_arr['pcs'] = request.POST['pcs']
            req_arr['xenit_nick'] = request.POST['xenit_nick']
            req_result = PC_CLASS.allocatepcgroup(req_arr) ########
            resp_arr['response'] = req_result['response']
            resp_arr['error_message'] = req_result['error_message']
        elif reqmod == 'change_allpc_bootmod':
            req_arr = {}
            req_arr['bootmod'] = request.POST['bootmod']
            req_result = PC_CLASS.change_allpc_bootmod(req_arr)
            resp_arr['response'] = req_result['response']
            resp_arr['error_message'] = req_result['error_message']
        elif reqmod == 'all_pc_bootmod_lists':
            req_result = PC_CLASS.get_pc_bootmod_all()
            resp_arr['response'] = req_result['response']
            resp_arr['error_message'] = req_result['error_message']
            resp_arr['initpcs'] = req_result['initpcs']
            resp_arr['uninitpcs'] = req_result['uninitpcs']

        
        result = HttpResponse( json.dumps(resp_arr), content_type="application/json")
        return result


    def apis(request):
        
        resp_arr = {}
        if not 'reqmod' in request.POST:
            resp_arr['response'] = 'fail'
            resp_arr['error_message'] = 'reqmod error'
            result = HttpResponse( json.dumps(resp_arr), content_type="application/json")
            return result
        reqmod = request.POST['reqmod']

        if reqmod == 'node_search_nodes':
            try:
                page = int(request.POST['page'])
                if page <= 1:
                    page = 1
            except Exception as e:
                page = 1
            try:
                req_arr = {}
                req_arr['searchword'] = request.POST['searchword']
                req_arr['page'] = page
                req_result = PC_CLASS.search_nodes(req_arr)
                resp_arr['arr'] = req_result
            except Exception as e:
                resp_arr2 = {}
                resp_arr2['response'] = 'failed'
                resp_arr2['error_message'] = 'failed'
                resp_arr2['data'] = []
                resp_arr2['next_page'] = 'N'
                resp_arr['arr'] = resp_arr2
        elif reqmod == 'setbootmod':
            try:
                req_arr = {}
                req_arr['boot_mod'] = request.POST['boot_mod']
                req_arr['pclists'] = request.POST['pclists']
                req_result = PC_CLASS.set_bootmod_nodes(req_arr)
                resp_arr['arr'] = req_result
            except Exception as e:
                resp_arr2 = {}
                resp_arr2['response'] = 'failed'
                resp_arr2['error_message'] = 'failed'
                resp_arr['arr'] = resp_arr2
        elif reqmod == 'setnodereset':
            try:
                req_arr = {}
                req_arr['pclists'] = request.POST['pclists']
                req_result = PC_CLASS.set_reset_nodes(req_arr)
                resp_arr['arr'] = req_result
            except Exception as e:
                resp_arr2 = {}
                resp_arr2['response'] = 'failed'
                resp_arr2['error_message'] = 'failed'
                resp_arr['arr'] = resp_arr2
        else:
            resp_arr2 = {}
            resp_arr2['response'] = 'failed'
            resp_arr2['error_message'] = 'api error'
            resp_arr['arr'] = resp_arr2

        result = HttpResponse( json.dumps(resp_arr), content_type="application/json")
        return result

    def manage_apis(request):
        resp_arr = {}
        if not 'reqmod' in request.POST:
            resp_arr['response'] = 'fail'
            resp_arr['error_message'] = 'reqmod error'
            result = HttpResponse( json.dumps(resp_arr), content_type="application/json")
            return result
        reqmod = request.POST['reqmod']

        if reqmod == 'shot':
            try:
                req_arr = {}
                req_arr['check_time'] = request.POST['check_time']
                resp_arr['arr'] = PC_CLASS.allpc_shot(req_arr)
            except Exception as e:
                resp_arr['arr'] = 'err %s' % (str(e.args[0]))
        elif reqmod == 'is_shot':
            result = PC_CLASS.is_shot()
            resp_arr['response'] = result

        result = HttpResponse( json.dumps(resp_arr), content_type="application/json")
        return result

class WINAPI():

    @csrf_exempt
    def requestAPI(request):
        resp_arr = {}
        if not 'reqmod' in request.POST:
            resp_arr['response'] = 'fail'
            resp_arr['error_message'] = 'reqmod error'
            result = HttpResponse( json.dumps(resp_arr), content_type="application/json")
            return result
        reqmod = request.POST['reqmod']
        if reqmod == 'info':
            try:
                req_arr = {}
                req_arr['mac'] = request.POST['mac']
                resp_arr = PC_CLASS.getinfo_node(req_arr)
            except Exception as e:
                resp_arr['response'] = 'failed'
                resp_arr['error_message'] = 'except error'
        else:
            resp_arr['response'] = 'failed'
            resp_arr['error_message'] = 'api error'
        result = HttpResponse( json.dumps(resp_arr), content_type="application/json")
        return result






