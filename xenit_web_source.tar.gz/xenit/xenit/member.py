from django.shortcuts import render
import django.db
import base64

class MEMBER():  
    def login(userid,password):
        result = {}  
        try:
            cursor = django.db.connections['default'].cursor()
            encrypt = base64.b64encode(bytes(password,"utf-8"))    
            en_passwd = encrypt.decode("utf-8")
            disklist = "select * from sys_member where userid = '" + userid + "' and userpasswd = '"+en_passwd+"'" 
            cursor.execute(disklist)
            db_data = cursor.fetchall()
            if int(len(db_data)) > 0 :
                client_info = []      
                for data in db_data:
                    response = {}
                    response['userid']= '%s' % (str(data[1]))
                    if str(data[3]) == '':
                        response['nick'] = '%s' % (str(data[1]))
                    else:
                        response['nick'] = '%s' % (str(data[3]))
                    response['level'] = '%s' % (str(data[4]))
                    client_info.append(response)
                result['response']='success'
                result['member_info'] = client_info[0]
            else:            
                result['response'] = 'failed'
                result['err_msg'] = 'login fail'  
            cursor.close();            
        except Exception as e:
            result['response'] = 'failed'
            result['err_msg'] = 'failed'
        return result

    def get_login(userid):
        result = {}  
        try:
            cursor = django.db.connections['default'].cursor()
            encrypt = base64.b64encode(bytes(password,"utf-8"))    
            en_passwd = encrypt.decode("utf-8")
            disklist = "select * from member limit 1"
            cursor.execute(disklist)
            db_data = cursor.fetchall()
            if int(len(db_data)) > 0 :
                client_info = []      
                for data in db_data:
                    response = {}
                    dec = base64.b64decode(bytes(str(data[2],"utf-8")))
                    dec_data = dec.decode("utf-8")
                    response['userid']= '%s' % (str(data[1]))
                    response['passwd'] = '%s' % (str(dec_data))
                    client_info.append(response)      
                result['result']='success'
                result['member_info'] = client_info[0]
            else:            
                result['result'] = 'failed'
                result['err_msg'] = 'login fail'  
            cursor.close();            
        except Exception as e:
            result['result'] = 'failed'
            result['err_msg'] = str(e.args[0])
        return result
