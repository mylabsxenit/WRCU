#from django.db import connection
from django.http import HttpResponseRedirect
import django.db

# view_func : @login_required method
# request : view_func' first argument
#def login_required(view_func, login_url='/test/user/login/?autherr=login'):
def login_required(view_func, login_url='/login'):
    def decorator(request, *args, **kwargs):
        # for login execute view method
        if 'name' in request.session:
            return view_func(request, *args, **kwargs)
        # ii's not login go to login pageredirect
        else:
            return HttpResponseRedirect(login_url)
    return decorator


# view_func : @permission_required method
# request : view_func's first argument
#def permission_required(view_func, login_url='/test/user/login/?autherr=perm'):
#def permission_required(view_func, login_url='login'):
#    def decorator(request, *args, **kwargs):
#        if has_permission(request):
#            return view_func(request, *args, **kwargs)
#        else:
#            return HttpResponseRedirect(login_url)
#    return decorator
