import os, re, django.db, sys, base64, subprocess, json, time, socket, hashlib, binascii
import telnetlib

from django.utils.translation import ugettext as _
from django.utils.translation import activate

class XENIT_CLASS():
    def dbconn():
        response = 'fail'
        tmppwfile = './xenit/static/tmpdata/listinfoshot'
        try:
            response = django.db.connections['default'].cursor()
            if os.path.exists(tmppwfile) == False:
                sudo_password = XENIT_CLASS.get_sys_passwd(response)
                if sudo_password != 'failed':
                    encrypt = base64.b64encode(bytes(sudo_password,"utf-8"))    
                    enc_pass = encrypt.decode("utf-8")
                    wfile3 = open(tmppwfile, "w")
                    wfile3.write(enc_pass)
                    wfile3.close()
            return response
        except Exception as e:
            return response

    def dbclose(dbconn):
        tmppwfile = './xenit/static/tmpdata/listinfoshot'
        try:
            dbconn.close()
            return 'success'
        except Exception as e:
            return 'success'


    def exec_window_client(req):
        resp_arr = []
        tmpfile = req['tmpfile']
        if os.path.exists(tmpfile) == False:
            return resp_arr


        try:
            execmod = 'exec_window'
            filepath = tmpfile
            #execcommand = 'python3 ./xenit/xenitcmm.py %s %s' % (str(execmod), str(filepath))
            execcommand = 'python3 ./xenit/xenitcmm %s %s' % (str(execmod), str(filepath))
            cmdarr = execcommand.split()
            cmdgroup = subprocess.Popen(cmdarr, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE, universal_newlines=True)
            stdout, stderr =  cmdgroup.communicate('\n')
            if stdout.strip() == 'success':
                result_file = open(tmpfile, "r")
                lines = result_file.readlines()
                result_file.close()
                for line in lines:
                    if line != '':
                        resp = {}
                        resp['pc_idx'] = line.strip().split('|')[0]
                        resp['pc_ip'] = line.strip().split('|')[1]
                        resp['pc_alias'] = line.strip().split('|')[2]
                        resp['result'] = line.strip().split('|')[3]
                        resp_arr.append(resp)
                if os.path.exists(tmpfile):
                    os.remove(tmpfile)
                return resp_arr
            else:
                if os.path.exists(tmpfile):
                    os.remove(tmpfile)
                return resp_arr
        except Exception as e:
            if os.path.exists(tmpfile):
                os.remove(tmpfile)
            return resp_arr
