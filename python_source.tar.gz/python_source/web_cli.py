# coding: utf-8
import os
import sys
import re
import subprocess
from PyQt4 import QtGui
from web_ui import Ui_Dialog


class First(QtGui.QDialog):
    def __init__(self, parent=None):
        super(First, self).__init__(parent)
        self._want_to_close = False
        QtGui.QDialog.__init__(self, parent)


        self.ui = Ui_Dialog() #this
        self.ui.setupUi(self) #this


if __name__ == '__main__':
    app = QtGui.QApplication(sys.argv)
    f = First()

    f.show()

    sys.exit(app.exec())

